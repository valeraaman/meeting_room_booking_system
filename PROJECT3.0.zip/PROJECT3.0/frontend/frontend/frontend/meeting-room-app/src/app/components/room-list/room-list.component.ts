import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { RoomService } from '../../services/room.service';
import { Room } from '../../models/room.model';

@Component({
  selector: 'app-room-list',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="room-list">
      <div class="header">
        <h2>Meeting Rooms</h2>
      </div>

      <div class="loading" *ngIf="loading">Loading rooms...</div>
      
      <div class="error" *ngIf="error">{{ error }}</div>

      <div class="rooms-grid" *ngIf="!loading && !error">
        <div class="room-card" *ngFor="let room of rooms">
          <div class="room-header">
            <h3>{{ room.name }}</h3>
            <span class="capacity-badge">{{ room.capacity }} people</span>
          </div>
          <div class="room-body">
            <p><strong>Location:</strong> {{ room.location }}</p>
            <p><strong>Amenities:</strong></p>
            <div class="amenities">
              <span class="amenity" *ngFor="let amenity of getAmenities(room.amenities)">
                {{ amenity }}
              </span>
            </div>
          </div>
          <div class="room-actions">
            <a [routerLink]="['/rooms', room.id]" class="btn btn-outline">View Details</a>
            <a [routerLink]="['/book', room.id]" class="btn btn-primary">Book Now</a>
          </div>
        </div>
      </div>

      <div class="empty-state" *ngIf="!loading && !error && rooms.length === 0">
        <p>No meeting rooms available.</p>
      </div>
    </div>
  `,
  styles: [`
    .room-list h2 {
      margin-bottom: 1.5rem;
      color: #333;
    }

    .loading, .error {
      padding: 2rem;
      text-align: center;
    }

    .error {
      color: #c62828;
      background: #ffebee;
      border-radius: 4px;
    }

    .rooms-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1.5rem;
    }

    .room-card {
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      overflow: hidden;
    }

    .room-header {
      background: #1976d2;
      color: white;
      padding: 1rem 1.5rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .room-header h3 {
      margin: 0;
    }

    .capacity-badge {
      background: rgba(255,255,255,0.2);
      padding: 0.25rem 0.75rem;
      border-radius: 12px;
      font-size: 0.875rem;
    }

    .room-body {
      padding: 1.5rem;
    }

    .room-body p {
      margin: 0 0 0.75rem;
    }

    .amenities {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      margin-top: 0.5rem;
    }

    .amenity {
      background: #e3f2fd;
      color: #1976d2;
      padding: 0.25rem 0.75rem;
      border-radius: 4px;
      font-size: 0.875rem;
    }

    .room-actions {
      padding: 1rem 1.5rem;
      border-top: 1px solid #eee;
      display: flex;
      gap: 1rem;
    }

    .btn {
      padding: 0.5rem 1rem;
      border-radius: 4px;
      text-decoration: none;
      font-weight: 500;
      text-align: center;
      flex: 1;
      transition: all 0.3s;
    }

    .btn-primary {
      background-color: #1976d2;
      color: white;
    }

    .btn-primary:hover {
      background-color: #1565c0;
    }

    .btn-outline {
      border: 1px solid #1976d2;
      color: #1976d2;
      background: white;
    }

    .btn-outline:hover {
      background: #e3f2fd;
    }

    .empty-state {
      text-align: center;
      padding: 3rem;
      background: white;
      border-radius: 8px;
    }
  `]
})
export class RoomListComponent implements OnInit {
  rooms: Room[] = [];
  loading = true;
  error = '';

  constructor(private roomService: RoomService) {}

  ngOnInit(): void {
    this.loadRooms();
  }

  loadRooms(): void {
    this.loading = true;
    this.roomService.getRooms().subscribe({
      next: (rooms) => {
        this.rooms = rooms;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load rooms. Please try again.';
        this.loading = false;
        console.error('Error loading rooms:', err);
      }
    });
  }

  getAmenities(amenities: string): string[] {
    return amenities.split(',').map(a => a.trim()).filter(a => a);
  }
}
