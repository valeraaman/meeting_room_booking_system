import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { RoomService } from '../../services/room.service';
import { RoomWithAvailability, TimeSlot } from '../../models/room.model';

@Component({
  selector: 'app-room-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
    <div class="room-detail" *ngIf="room">
      <div class="back-link">
        <a routerLink="/rooms">← Back to Rooms</a>
      </div>

      <div class="room-header">
        <h2>{{ room.name }}</h2>
        <a [routerLink]="['/book', room.id]" class="btn btn-primary">Book This Room</a>
      </div>

      <div class="room-info">
        <div class="info-card">
          <h3>Room Details</h3>
          <p><strong>Capacity:</strong> {{ room.capacity }} people</p>
          <p><strong>Location:</strong> {{ room.location }}</p>
          <div class="amenities-section">
            <strong>Amenities:</strong>
            <div class="amenities">
              <span class="amenity" *ngFor="let amenity of getAmenities(room.amenities)">
                {{ amenity }}
              </span>
            </div>
          </div>
        </div>

        <div class="availability-card">
          <h3>Check Availability</h3>
          <div class="date-selector">
            <label for="date">Select Date:</label>
            <input 
              type="date" 
              id="date" 
              [(ngModel)]="selectedDate" 
              (change)="loadAvailability()"
              [min]="minDate">
          </div>

          <div class="schedule" *ngIf="room.bookedSlots.length > 0">
            <h4>Booked Slots for {{ formatDate(selectedDate) }}</h4>
            <div class="slot" *ngFor="let slot of room.bookedSlots">
              <div class="slot-time">
                {{ formatTime(slot.startTime) }} - {{ formatTime(slot.endTime) }}
              </div>
              <div class="slot-details">
                <span class="meeting-title">{{ slot.meetingTitle }}</span>
                <span class="booked-by">by {{ slot.bookedBy }}</span>
              </div>
            </div>
          </div>

          <div class="no-bookings" *ngIf="room.bookedSlots.length === 0">
            <p>No bookings for {{ formatDate(selectedDate) }}. This room is available all day!</p>
          </div>
        </div>
      </div>
    </div>

    <div class="loading" *ngIf="loading">Loading room details...</div>
    <div class="error" *ngIf="error">{{ error }}</div>
  `,
  styles: [`
    .back-link {
      margin-bottom: 1rem;
    }

    .back-link a {
      color: #1976d2;
      text-decoration: none;
    }

    .back-link a:hover {
      text-decoration: underline;
    }

    .room-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    .room-header h2 {
      margin: 0;
      color: #333;
    }

    .btn-primary {
      background-color: #1976d2;
      color: white;
      padding: 0.75rem 1.5rem;
      border-radius: 4px;
      text-decoration: none;
      font-weight: 500;
    }

    .btn-primary:hover {
      background-color: #1565c0;
    }

    .room-info {
      display: grid;
      grid-template-columns: 1fr 2fr;
      gap: 2rem;
    }

    .info-card, .availability-card {
      background: white;
      padding: 1.5rem;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .info-card h3, .availability-card h3 {
      margin-top: 0;
      color: #333;
      border-bottom: 2px solid #1976d2;
      padding-bottom: 0.5rem;
    }

    .info-card p {
      margin: 0.75rem 0;
    }

    .amenities-section {
      margin-top: 1rem;
    }

    .amenities {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      margin-top: 0.5rem;
    }

    .amenity {
      background: #e3f2fd;
      color: #1976d2;
      padding: 0.25rem 0.75rem;
      border-radius: 4px;
      font-size: 0.875rem;
    }

    .date-selector {
      margin-bottom: 1.5rem;
    }

    .date-selector label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
    }

    .date-selector input {
      padding: 0.5rem;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 1rem;
    }

    .schedule h4 {
      margin-top: 0;
      color: #666;
    }

    .slot {
      display: flex;
      gap: 1rem;
      padding: 1rem;
      background: #fff3e0;
      border-radius: 4px;
      margin-bottom: 0.75rem;
      border-left: 4px solid #ff9800;
    }

    .slot-time {
      font-weight: 600;
      color: #e65100;
      min-width: 150px;
    }

    .slot-details {
      display: flex;
      flex-direction: column;
    }

    .meeting-title {
      font-weight: 500;
    }

    .booked-by {
      font-size: 0.875rem;
      color: #666;
    }

    .no-bookings {
      background: #e8f5e9;
      padding: 1rem;
      border-radius: 4px;
      color: #2e7d32;
    }

    .loading, .error {
      padding: 2rem;
      text-align: center;
      background: white;
      border-radius: 8px;
    }

    .error {
      color: #c62828;
      background: #ffebee;
    }

    @media (max-width: 768px) {
      .room-info {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class RoomDetailComponent implements OnInit {
  room: RoomWithAvailability | null = null;
  loading = true;
  error = '';
  selectedDate: string;
  minDate: string;

  constructor(
    private route: ActivatedRoute,
    private roomService: RoomService
  ) {
    const today = new Date();
    this.selectedDate = today.toISOString().split('T')[0];
    this.minDate = this.selectedDate;
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.loadRoom(parseInt(id));
    }
  }

  loadRoom(id: number): void {
    this.loadAvailability();
  }

  loadAvailability(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (!id) return;

    this.loading = true;
    const date = new Date(this.selectedDate);
    
    this.roomService.getRoomAvailability(parseInt(id), date).subscribe({
      next: (room) => {
        this.room = room;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load room details. Please try again.';
        this.loading = false;
        console.error('Error loading room:', err);
      }
    });
  }

  getAmenities(amenities: string): string[] {
    return amenities.split(',').map(a => a.trim()).filter(a => a);
  }

  formatDate(dateStr: string): string {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  }

  formatTime(time: string): string {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  }
}
