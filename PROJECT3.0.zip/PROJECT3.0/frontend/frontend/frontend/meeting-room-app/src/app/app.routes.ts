import { Routes } from '@angular/router';
import { RoomListComponent } from './components/room-list/room-list.component';
import { RoomDetailComponent } from './components/room-detail/room-detail.component';
import { BookingFormComponent } from './components/booking-form/booking-form.component';
import { BookingListComponent } from './components/booking-list/booking-list.component';
import { MyBookingsComponent } from './components/my-bookings/my-bookings.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';

export const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'rooms', component: RoomListComponent },
  { path: 'rooms/:id', component: RoomDetailComponent },
  { path: 'book', component: BookingFormComponent },
  { path: 'book/:roomId', component: BookingFormComponent },
  { path: 'bookings', component: BookingListComponent },
  { path: 'bookings/edit/:id', component: BookingFormComponent },
  { path: 'my-bookings', component: MyBookingsComponent },
  { path: '**', redirectTo: '/dashboard' }
];
