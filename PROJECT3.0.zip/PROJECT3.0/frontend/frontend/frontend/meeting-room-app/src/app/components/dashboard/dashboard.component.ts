import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { RoomService } from '../../services/room.service';
import { BookingService } from '../../services/booking.service';
import { Room } from '../../models/room.model';
import { Booking } from '../../models/booking.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="dashboard">
      <h2>Dashboard</h2>
      
      <div class="stats-container">
        <div class="stat-card">
          <h3>{{ rooms.length }}</h3>
          <p>Available Rooms</p>
        </div>
        <div class="stat-card">
          <h3>{{ todayBookings.length }}</h3>
          <p>Today's Bookings</p>
        </div>
        <div class="stat-card">
          <h3>{{ upcomingBookings.length }}</h3>
          <p>Upcoming Bookings</p>
        </div>
      </div>

      <div class="quick-actions">
        <h3>Quick Actions</h3>
        <div class="action-buttons">
          <a routerLink="/book" class="btn btn-primary">Book a Room</a>
          <a routerLink="/rooms" class="btn btn-secondary">View All Rooms</a>
          <a routerLink="/my-bookings" class="btn btn-secondary">My Bookings</a>
        </div>
      </div>

      <div class="today-schedule" *ngIf="todayBookings.length > 0">
        <h3>Today's Schedule</h3>
        <div class="booking-list">
          <div class="booking-card" *ngFor="let booking of todayBookings">
            <div class="booking-time">
              {{ formatTime(booking.startTime) }} - {{ formatTime(booking.endTime) }}
            </div>
            <div class="booking-details">
              <h4>{{ booking.meetingTitle }}</h4>
              <p>{{ booking.roomName }} • {{ booking.employeeName }}</p>
            </div>
            <div class="booking-status" [class]="booking.status.toLowerCase()">
              {{ booking.status }}
            </div>
          </div>
        </div>
      </div>

      <div class="rooms-overview">
        <h3>Rooms Overview</h3>
        <div class="rooms-grid">
          <div class="room-card" *ngFor="let room of rooms">
            <h4>{{ room.name }}</h4>
            <p><strong>Capacity:</strong> {{ room.capacity }} people</p>
            <p><strong>Location:</strong> {{ room.location }}</p>
            <a [routerLink]="['/book', room.id]" class="btn btn-sm">Book Now</a>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard h2 {
      margin-bottom: 1.5rem;
      color: #333;
    }

    .stats-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .stat-card {
      background: white;
      padding: 1.5rem;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      text-align: center;
    }

    .stat-card h3 {
      font-size: 2.5rem;
      color: #1976d2;
      margin: 0;
    }

    .stat-card p {
      color: #666;
      margin: 0.5rem 0 0;
    }

    .quick-actions {
      background: white;
      padding: 1.5rem;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      margin-bottom: 2rem;
    }

    .quick-actions h3 {
      margin-top: 0;
      margin-bottom: 1rem;
    }

    .action-buttons {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
    }

    .btn {
      padding: 0.75rem 1.5rem;
      border-radius: 4px;
      text-decoration: none;
      font-weight: 500;
      transition: background-color 0.3s;
    }

    .btn-primary {
      background-color: #1976d2;
      color: white;
    }

    .btn-primary:hover {
      background-color: #1565c0;
    }

    .btn-secondary {
      background-color: #f5f5f5;
      color: #333;
    }

    .btn-secondary:hover {
      background-color: #e0e0e0;
    }

    .btn-sm {
      padding: 0.5rem 1rem;
      font-size: 0.875rem;
      background-color: #1976d2;
      color: white;
    }

    .today-schedule {
      background: white;
      padding: 1.5rem;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      margin-bottom: 2rem;
    }

    .today-schedule h3 {
      margin-top: 0;
    }

    .booking-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .booking-card {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 1rem;
      background: #f9f9f9;
      border-radius: 4px;
      border-left: 4px solid #1976d2;
    }

    .booking-time {
      font-weight: 600;
      color: #1976d2;
      min-width: 120px;
    }

    .booking-details {
      flex: 1;
    }

    .booking-details h4 {
      margin: 0 0 0.25rem;
    }

    .booking-details p {
      margin: 0;
      color: #666;
      font-size: 0.875rem;
    }

    .booking-status {
      padding: 0.25rem 0.75rem;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 500;
      text-transform: uppercase;
    }

    .booking-status.confirmed {
      background-color: #e8f5e9;
      color: #2e7d32;
    }

    .booking-status.cancelled {
      background-color: #ffebee;
      color: #c62828;
    }

    .rooms-overview {
      background: white;
      padding: 1.5rem;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .rooms-overview h3 {
      margin-top: 0;
    }

    .rooms-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1rem;
    }

    .room-card {
      padding: 1rem;
      background: #f9f9f9;
      border-radius: 4px;
    }

    .room-card h4 {
      margin: 0 0 0.5rem;
      color: #1976d2;
    }

    .room-card p {
      margin: 0.25rem 0;
      font-size: 0.875rem;
    }
  `]
})
export class DashboardComponent implements OnInit {
  rooms: Room[] = [];
  todayBookings: Booking[] = [];
  upcomingBookings: Booking[] = [];

  constructor(
    private roomService: RoomService,
    private bookingService: BookingService
  ) {}

  ngOnInit(): void {
    this.loadRooms();
    this.loadTodayBookings();
    this.loadUpcomingBookings();
  }

  loadRooms(): void {
    this.roomService.getRooms().subscribe({
      next: (rooms) => this.rooms = rooms,
      error: (err) => console.error('Error loading rooms:', err)
    });
  }

  loadTodayBookings(): void {
    this.bookingService.getBookings(new Date()).subscribe({
      next: (bookings) => this.todayBookings = bookings.filter(b => b.status === 'Confirmed'),
      error: (err) => console.error('Error loading today bookings:', err)
    });
  }

  loadUpcomingBookings(): void {
    this.bookingService.getBookings().subscribe({
      next: (bookings) => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        this.upcomingBookings = bookings.filter(b => 
          new Date(b.bookingDate) >= today && b.status === 'Confirmed'
        );
      },
      error: (err) => console.error('Error loading upcoming bookings:', err)
    });
  }

  formatTime(time: string): string {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  }
}
