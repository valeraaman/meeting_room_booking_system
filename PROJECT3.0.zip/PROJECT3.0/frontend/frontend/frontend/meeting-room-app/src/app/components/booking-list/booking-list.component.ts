import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { BookingService } from '../../services/booking.service';
import { RoomService } from '../../services/room.service';
import { Booking } from '../../models/booking.model';
import { Room } from '../../models/room.model';

@Component({
  selector: 'app-booking-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="booking-list">
      <h2>All Bookings</h2>

      <div class="filters">
        <div class="filter-group">
          <label for="dateFilter">Date:</label>
          <input type="date" id="dateFilter" [(ngModel)]="filterDate" (change)="applyFilters()">
        </div>
        <div class="filter-group">
          <label for="roomFilter">Room:</label>
          <select id="roomFilter" [(ngModel)]="filterRoomId" (change)="applyFilters()">
            <option value="">All Rooms</option>
            <option *ngFor="let room of rooms" [value]="room.id">{{ room.name }}</option>
          </select>
        </div>
        <button class="btn btn-secondary" (click)="clearFilters()">Clear Filters</button>
      </div>

      <div class="loading" *ngIf="loading">Loading bookings...</div>

      <div class="bookings-table" *ngIf="!loading && bookings.length > 0">
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Time</th>
              <th>Room</th>
              <th>Meeting</th>
              <th>Booked By</th>
              <th>Attendees</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let booking of bookings" [class.cancelled]="booking.status === 'Cancelled'">
              <td>{{ formatDate(booking.bookingDate) }}</td>
              <td>{{ formatTime(booking.startTime) }} - {{ formatTime(booking.endTime) }}</td>
              <td>{{ booking.roomName }}</td>
              <td>{{ booking.meetingTitle }}</td>
              <td>{{ booking.employeeName }}</td>
              <td>{{ booking.attendeesCount }}</td>
              <td>
                <span class="status-badge" [class]="booking.status.toLowerCase()">
                  {{ booking.status }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="empty-state" *ngIf="!loading && bookings.length === 0">
        <p>No bookings found matching your criteria.</p>
      </div>
    </div>
  `,
  styles: [`
    .booking-list h2 {
      color: #333;
      margin-bottom: 1.5rem;
    }

    .filters {
      display: flex;
      gap: 1rem;
      align-items: flex-end;
      margin-bottom: 1.5rem;
      padding: 1rem;
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      flex-wrap: wrap;
    }

    .filter-group {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .filter-group label {
      font-weight: 500;
      color: #666;
    }

    .filter-group input,
    .filter-group select {
      padding: 0.5rem;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 1rem;
    }

    .btn-secondary {
      padding: 0.5rem 1rem;
      background: #f5f5f5;
      border: 1px solid #ddd;
      border-radius: 4px;
      cursor: pointer;
    }

    .btn-secondary:hover {
      background: #e0e0e0;
    }

    .loading {
      padding: 2rem;
      text-align: center;
      background: white;
      border-radius: 8px;
    }

    .bookings-table {
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      overflow: hidden;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      padding: 1rem;
      text-align: left;
      border-bottom: 1px solid #eee;
    }

    th {
      background: #f5f5f5;
      font-weight: 600;
      color: #333;
    }

    tr:hover {
      background: #fafafa;
    }

    tr.cancelled {
      opacity: 0.6;
    }

    .status-badge {
      padding: 0.25rem 0.75rem;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 500;
      text-transform: uppercase;
    }

    .status-badge.confirmed {
      background: #e8f5e9;
      color: #2e7d32;
    }

    .status-badge.cancelled {
      background: #ffebee;
      color: #c62828;
    }

    .status-badge.completed {
      background: #e3f2fd;
      color: #1565c0;
    }

    .empty-state {
      padding: 3rem;
      text-align: center;
      background: white;
      border-radius: 8px;
    }

    @media (max-width: 768px) {
      .bookings-table {
        overflow-x: auto;
      }
      
      table {
        min-width: 700px;
      }
    }
  `]
})
export class BookingListComponent implements OnInit {
  bookings: Booking[] = [];
  rooms: Room[] = [];
  loading = true;
  
  filterDate = '';
  filterRoomId = '';

  constructor(
    private bookingService: BookingService,
    private roomService: RoomService
  ) {}

  ngOnInit(): void {
    this.loadRooms();
    this.loadBookings();
  }

  loadRooms(): void {
    this.roomService.getRooms().subscribe({
      next: (rooms) => this.rooms = rooms,
      error: (err) => console.error('Error loading rooms:', err)
    });
  }

  loadBookings(): void {
    this.loading = true;
    
    const date = this.filterDate ? new Date(this.filterDate) : undefined;
    const roomId = this.filterRoomId ? parseInt(this.filterRoomId) : undefined;

    this.bookingService.getBookings(date, roomId).subscribe({
      next: (bookings) => {
        this.bookings = bookings;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading bookings:', err);
        this.loading = false;
      }
    });
  }

  applyFilters(): void {
    this.loadBookings();
  }

  clearFilters(): void {
    this.filterDate = '';
    this.filterRoomId = '';
    this.loadBookings();
  }

  formatDate(dateStr: string | Date): string {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  }

  formatTime(time: string): string {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  }
}
