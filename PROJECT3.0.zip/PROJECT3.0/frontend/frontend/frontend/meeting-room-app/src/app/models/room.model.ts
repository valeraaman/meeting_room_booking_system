export interface Room {
  id: number;
  name: string;
  capacity: number;
  location: string;
  amenities: string;
  isActive: boolean;
}

export interface RoomWithAvailability {
  id: number;
  name: string;
  capacity: number;
  location: string;
  amenities: string;
  bookedSlots: TimeSlot[];
}

export interface TimeSlot {
  startTime: string;
  endTime: string;
  meetingTitle: string;
  bookedBy: string;
}

export interface CreateRoom {
  name: string;
  capacity: number;
  location: string;
  amenities: string;
}
