import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Room, RoomWithAvailability, CreateRoom } from '../models/room.model';

@Injectable({
  providedIn: 'root'
})
export class RoomService {
 private apiUrl = 'https://localhost:7171/api/Rooms';

  constructor(private http: HttpClient) {}

  getRooms(): Observable<Room[]> {
    return this.http.get<Room[]>(this.apiUrl);
  }

  getRoom(id: number): Observable<Room> {
    return this.http.get<Room>(`${this.apiUrl}/${id}`);
  }

  getRoomAvailability(id: number, date: Date): Observable<RoomWithAvailability> {
    const params = new HttpParams().set('date', date.toISOString().split('T')[0]);
    return this.http.get<RoomWithAvailability>(`${this.apiUrl}/${id}/availability`, { params });
  }

  getAvailableRooms(date: Date, startTime: string, endTime: string, capacity?: number): Observable<Room[]> {
    let params = new HttpParams()
      .set('date', date.toISOString().split('T')[0])
      .set('startTime', startTime)
      .set('endTime', endTime);
    
    if (capacity) {
      params = params.set('capacity', capacity.toString());
    }

    return this.http.get<Room[]>(`${this.apiUrl}/available`, { params });
  }

  createRoom(room: CreateRoom): Observable<Room> {
    return this.http.post<Room>(this.apiUrl, room);
  }

  updateRoom(id: number, room: CreateRoom): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, room);
  }

  deleteRoom(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
    