import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Booking, CreateBooking, CheckAvailability } from '../models/booking.model';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  private apiUrl = 'https://localhost:7171/api/Bookings';

  constructor(private http: HttpClient) {}

  getBookings(date?: Date, roomId?: number, employeeId?: string): Observable<Booking[]> {

    let params = new HttpParams();

    if (date) {
      params = params.set('date', date.toISOString().split('T')[0]);
    }

    if (roomId) {
      params = params.set('roomId', roomId.toString());
    }

    if (employeeId) {
      params = params.set('employeeId', employeeId);
    }

    return this.http.get<Booking[]>(this.apiUrl, { params });
  }

  getBooking(id: number): Observable<Booking> {
    return this.http.get<Booking>(`${this.apiUrl}/${id}`);
  }

  getMyBookings(employeeId: string): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.apiUrl}/my-bookings/${employeeId}`);
  }

  createBooking(booking: CreateBooking): Observable<Booking> {
    return this.http.post<Booking>(this.apiUrl, booking);
  }

  updateBooking(id: number, booking: CreateBooking): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, booking);
  }

  cancelBooking(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  checkAvailability(data: CheckAvailability): Observable<boolean> {
    return this.http.post<boolean>(`${this.apiUrl}/check-availability`, data);
  }
}