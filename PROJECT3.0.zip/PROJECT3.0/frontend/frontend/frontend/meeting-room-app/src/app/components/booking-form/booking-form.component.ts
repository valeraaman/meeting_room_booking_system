import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { RoomService } from '../../services/room.service';
import { BookingService } from '../../services/booking.service';
import { Room } from '../../models/room.model';
import { CreateBooking } from '../../models/booking.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-booking-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, RouterLink],
  templateUrl: './booking-form.component.html',
  styleUrls: ['./booking-form.component.css']
})
export class BookingFormComponent implements OnInit {

  bookingForm!: FormGroup;
  rooms: Room[] = [];
  selectedRoom: Room | null = null;

  isEditMode = false;
  editingBookingId: number | null = null;

  minDate: string;
  timeSlots: { value: string; display: string }[] = [];

  isAvailable = false;
  availabilityChecked = false;
  timeError = '';

  submitError = '';
  submitSuccess = '';
  submitting = false;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private roomService: RoomService,
    private bookingService: BookingService
  ) {

    const today = new Date();
    this.minDate = today.toISOString().split('T')[0];

    this.generateTimeSlots();

    this.bookingForm = this.fb.group({
      roomId: ['', Validators.required],
      meetingTitle: ['', Validators.required],
      description: [''],
      employeeId: ['', Validators.required],
      employeeName: ['', Validators.required],
      attendeesCount: [1, [Validators.required, Validators.min(1)]],
      bookingDate: [this.minDate, Validators.required],
      startTime: ['', Validators.required],
      endTime: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadRooms();

    const bookingId = this.route.snapshot.paramMap.get('id');

    if (bookingId) {
      this.isEditMode = true;
      this.editingBookingId = parseInt(bookingId);
      this.loadBookingForEdit(this.editingBookingId);
    }

    const roomId = this.route.snapshot.paramMap.get('roomId');

    if (roomId) {
      this.bookingForm.patchValue({ roomId: parseInt(roomId) });
    }
  }

  generateTimeSlots(): void {

    for (let hour = 8; hour <= 20; hour++) {

      for (let minute of [0, 30]) {

        const value =
          `${hour.toString().padStart(2, '0')}:${minute
            .toString()
            .padStart(2, '0')}:00`;

        const displayHour = hour > 12 ? hour - 12 : hour;
        const ampm = hour >= 12 ? 'PM' : 'AM';

        const display =
          `${displayHour}:${minute.toString().padStart(2, '0')} ${ampm}`;

        this.timeSlots.push({ value, display });
      }
    }
  }

  loadRooms(): void {

    this.roomService.getRooms().subscribe({
      next: (rooms: Room[]) => {
        this.rooms = rooms;
        this.onRoomChange();
      },
      error: (err: any) => {
        console.error('Error loading rooms:', err);
      }
    });
  }

  loadBookingForEdit(id: number): void {

    this.bookingService.getBooking(id).subscribe({
      next: (booking: any) => {

        this.bookingForm.patchValue({

          roomId: booking.roomId,
          meetingTitle: booking.meetingTitle,
          description: booking.description,
          employeeId: booking.employeeId,
          employeeName: booking.employeeName,
          attendeesCount: booking.attendeesCount,
          bookingDate:
            new Date(booking.bookingDate).toISOString().split('T')[0],
          startTime: booking.startTime,
          endTime: booking.endTime

        });

        this.onRoomChange();
        this.checkAvailability();
      },

      error: (err: any) => {
        console.error('Error loading booking:', err);
        this.submitError = 'Failed to load booking for editing.';
      }
    });
  }

  onRoomChange(): void {

    const roomId = parseInt(this.bookingForm.get('roomId')?.value);
    this.selectedRoom = this.rooms.find(r => r.id === roomId) || null;

    this.checkAvailability();
  }

  checkAvailability(): void {

    this.timeError = '';
    this.availabilityChecked = false;

    const roomId = this.bookingForm.get('roomId')?.value;
    const bookingDate = this.bookingForm.get('bookingDate')?.value;
    const startTime = this.bookingForm.get('startTime')?.value;
    const endTime = this.bookingForm.get('endTime')?.value;

    if (!roomId || !bookingDate || !startTime || !endTime) {
      return;
    }

    if (startTime >= endTime) {

      this.timeError = 'End time must be after start time';
      this.isAvailable = false;
      return;
    }

    this.bookingService.checkAvailability({

      roomId: parseInt(roomId),
      date: bookingDate,
      startTime: startTime,
      endTime: endTime

    }).subscribe({

      next: (available: boolean) => {

        this.isAvailable = available || this.isEditMode;
        this.availabilityChecked = true;
      },

      error: (err: any) => {

        console.error('Error checking availability:', err);
        this.isAvailable = false;
        this.availabilityChecked = true;
      }
    });
  }

  onSubmit(): void {
if (!this.bookingForm.valid) {
  alert("Please fill all required fields");
  return;
}

    this.submitting = true;
    this.submitError = '';
    this.submitSuccess = '';

    const formValue = this.bookingForm.value;

    const booking: CreateBooking = {

      roomId: parseInt(formValue.roomId),
      employeeId: formValue.employeeId,
      employeeName: formValue.employeeName,
      meetingTitle: formValue.meetingTitle,
      description: formValue.description || '',
      bookingDate: formValue.bookingDate,
      startTime: formValue.startTime,
      endTime: formValue.endTime,
      attendeesCount: formValue.attendeesCount

    };

    console.log("Submitting booking:", booking);

    let request: Observable<any>;

    if (this.isEditMode && this.editingBookingId) {

      request =
        this.bookingService.updateBooking(this.editingBookingId, booking);

    } else {

      request =
        this.bookingService.createBooking(booking);
    }

    request.subscribe({

      next: () => {

        alert("Booking saved successfully");

        this.router.navigate(['/my-bookings']);
      },

      error: (err: any) => {

        console.error('Error saving booking:', err);

        this.submitError = 'Failed to save booking.';
      }
    });
  }
}