export interface Booking {
  id: number;
  roomId: number;
  roomName: string;
  employeeId: string;
  employeeName: string;
  meetingTitle: string;
  description: string;
  bookingDate: Date;
  startTime: string;
  endTime: string;
  attendeesCount: number;
  status: string;
  createdAt: Date;
}

export interface CreateBooking {
  roomId: number;
  employeeId: string;
  employeeName: string;
  meetingTitle: string;
  description: string;
  bookingDate: string;
  startTime: string;
  endTime: string;
  attendeesCount: number;
}

export interface CheckAvailability {
  roomId: number;
  date: string;
  startTime: string;
  endTime: string;
}
