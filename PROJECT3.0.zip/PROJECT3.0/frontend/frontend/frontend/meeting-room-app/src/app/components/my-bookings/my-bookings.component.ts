import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { BookingService } from '../../services/booking.service';
import { Booking } from '../../models/booking.model';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="my-bookings">
      <h2>My Bookings</h2>

      <div class="employee-selector">
        <label for="employeeId">Enter Your Employee ID:</label>
        <div class="input-group">
          <input 
            type="text" 
            id="employeeId" 
            [(ngModel)]="employeeId" 
            placeholder="e.g., EMP001"
            (keyup.enter)="loadMyBookings()">
          <button class="btn btn-primary" (click)="loadMyBookings()">View Bookings</button>
        </div>
      </div>

      <div class="loading" *ngIf="loading">Loading your bookings...</div>

      <div class="bookings-container" *ngIf="!loading && searched">
        <div class="booking-card" *ngFor="let booking of bookings">
          <div class="booking-header" [class.cancelled]="booking.status === 'Cancelled'">
            <div class="booking-date">
              <span class="day">{{ getDayOfMonth(booking.bookingDate) }}</span>
              <span class="month">{{ getMonth(booking.bookingDate) }}</span>
            </div>
            <div class="booking-info">
              <h3>{{ booking.meetingTitle }}</h3>
              <p class="room">{{ booking.roomName }}</p>
              <p class="time">{{ formatTime(booking.startTime) }} - {{ formatTime(booking.endTime) }}</p>
            </div>
            <div class="booking-status">
              <span class="status-badge" [class]="booking.status.toLowerCase()">
                {{ booking.status }}
              </span>
            </div>
          </div>
          <div class="booking-body">
            <p *ngIf="booking.description"><strong>Description:</strong> {{ booking.description }}</p>
            <p><strong>Attendees:</strong> {{ booking.attendeesCount }}</p>
            <p><strong>Booked on:</strong> {{ formatDateTime(booking.createdAt) }}</p>
          </div>
          <div class="booking-actions" *ngIf="booking.status === 'Confirmed'">
            <a [routerLink]="['/bookings/edit', booking.id]" class="btn btn-outline">Edit</a>
            <button class="btn btn-danger" (click)="cancelBooking(booking)">Cancel</button>
          </div>
        </div>

        <div class="empty-state" *ngIf="bookings.length === 0">
          <p>No upcoming bookings found for employee ID: {{ employeeId }}</p>
          <a routerLink="/book" class="btn btn-primary">Book a Room</a>
        </div>
      </div>

      <div class="cancel-modal" *ngIf="showCancelModal">
        <div class="modal-content">
          <h3>Cancel Booking</h3>
          <p>Are you sure you want to cancel the booking for "{{ bookingToCancel?.meetingTitle }}"?</p>
          <div class="modal-actions">
            <button class="btn btn-secondary" (click)="closeCancelModal()">No, Keep It</button>
            <button class="btn btn-danger" (click)="confirmCancel()">Yes, Cancel</button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .my-bookings h2 {
      color: #333;
      margin-bottom: 1.5rem;
    }

    .employee-selector {
      background: white;
      padding: 1.5rem;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      margin-bottom: 2rem;
    }

    .employee-selector label {
      display: block;
      margin-bottom: 0.5rem;
      font-weight: 500;
    }

    .input-group {
      display: flex;
      gap: 1rem;
    }

    .input-group input {
      flex: 1;
      padding: 0.75rem;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 1rem;
      max-width: 300px;
    }

    .btn {
      padding: 0.75rem 1.5rem;
      border-radius: 4px;
      font-weight: 500;
      cursor: pointer;
      border: none;
      text-decoration: none;
      display: inline-block;
      text-align: center;
    }

    .btn-primary {
      background-color: #1976d2;
      color: white;
    }

    .btn-primary:hover {
      background-color: #1565c0;
    }

    .btn-outline {
      border: 1px solid #1976d2;
      color: #1976d2;
      background: white;
    }

    .btn-outline:hover {
      background: #e3f2fd;
    }

    .btn-secondary {
      background: #f5f5f5;
      color: #333;
    }

    .btn-danger {
      background: #c62828;
      color: white;
    }

    .btn-danger:hover {
      background: #b71c1c;
    }

    .loading {
      padding: 2rem;
      text-align: center;
      background: white;
      border-radius: 8px;
    }

    .bookings-container {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .booking-card {
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      overflow: hidden;
    }

    .booking-header {
      display: flex;
      align-items: center;
      gap: 1.5rem;
      padding: 1.5rem;
      background: linear-gradient(135deg, #1976d2, #1565c0);
      color: white;
    }

    .booking-header.cancelled {
      background: linear-gradient(135deg, #757575, #616161);
    }

    .booking-date {
      text-align: center;
      min-width: 60px;
    }

    .booking-date .day {
      display: block;
      font-size: 2rem;
      font-weight: 700;
      line-height: 1;
    }

    .booking-date .month {
      display: block;
      font-size: 0.875rem;
      text-transform: uppercase;
    }

    .booking-info {
      flex: 1;
    }

    .booking-info h3 {
      margin: 0 0 0.25rem;
    }

    .booking-info p {
      margin: 0;
      opacity: 0.9;
    }

    .booking-info .room {
      font-weight: 500;
    }

    .booking-info .time {
      font-size: 0.875rem;
    }

    .booking-status .status-badge {
      padding: 0.5rem 1rem;
      border-radius: 20px;
      font-size: 0.75rem;
      font-weight: 600;
      text-transform: uppercase;
    }

    .status-badge.confirmed {
      background: rgba(255,255,255,0.2);
      color: white;
    }

    .status-badge.cancelled {
      background: rgba(255,255,255,0.2);
      color: white;
    }

    .booking-body {
      padding: 1.5rem;
      border-bottom: 1px solid #eee;
    }

    .booking-body p {
      margin: 0.5rem 0;
    }

    .booking-actions {
      padding: 1rem 1.5rem;
      display: flex;
      gap: 1rem;
      justify-content: flex-end;
    }

    .empty-state {
      text-align: center;
      padding: 3rem;
      background: white;
      border-radius: 8px;
    }

    .empty-state p {
      margin-bottom: 1rem;
      color: #666;
    }

    .cancel-modal {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.5);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }

    .modal-content {
      background: white;
      padding: 2rem;
      border-radius: 8px;
      max-width: 400px;
      width: 90%;
    }

    .modal-content h3 {
      margin-top: 0;
      color: #c62828;
    }

    .modal-actions {
      display: flex;
      gap: 1rem;
      justify-content: flex-end;
      margin-top: 1.5rem;
    }
  `]
})
export class MyBookingsComponent implements OnInit {
  employeeId = '';
  bookings: Booking[] = [];
  loading = false;
  searched = false;
  
  showCancelModal = false;
  bookingToCancel: Booking | null = null;

  constructor(private bookingService: BookingService) {}

  ngOnInit(): void {
    // Check if there's a stored employee ID
    const storedId = localStorage.getItem('employeeId');
    if (storedId) {
      this.employeeId = storedId;
      this.loadMyBookings();
    }
  }

  loadMyBookings(): void {
    if (!this.employeeId.trim()) {
      return;
    }

    this.loading = true;
    this.searched = true;
    
    // Store employee ID for convenience
    localStorage.setItem('employeeId', this.employeeId);

    this.bookingService.getMyBookings(this.employeeId).subscribe({
      next: (bookings) => {
        this.bookings = bookings;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading bookings:', err);
        this.loading = false;
      }
    });
  }

  cancelBooking(booking: Booking): void {
    this.bookingToCancel = booking;
    this.showCancelModal = true;
  }

  closeCancelModal(): void {
    this.showCancelModal = false;
    this.bookingToCancel = null;
  }

  confirmCancel(): void {
    if (!this.bookingToCancel) return;

    this.bookingService.cancelBooking(this.bookingToCancel.id).subscribe({
      next: () => {
        this.closeCancelModal();
        this.loadMyBookings();
      },
      error: (err) => {
        console.error('Error cancelling booking:', err);
        this.closeCancelModal();
      }
    });
  }

  getDayOfMonth(dateStr: string | Date): string {
    return new Date(dateStr).getDate().toString();
  }

  getMonth(dateStr: string | Date): string {
    return new Date(dateStr).toLocaleDateString('en-US', { month: 'short' });
  }

  formatTime(time: string): string {
    const [hours, minutes] = time.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  }

  formatDateTime(dateStr: string | Date): string {
    return new Date(dateStr).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  }
}
