﻿namespace MeetingRoomBooking.API.Models
{
    public class Booking
    {
        public int Id { get; set; }
        public int RoomId { get; set; }
        public string EmployeeId { get; set; } = string.Empty;
        public string EmployeeName { get; set; } = string.Empty;
        public string MeetingTitle { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime BookingDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public int AttendeesCount { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public BookingStatus Status { get; set; } = BookingStatus.Confirmed;

        public Room Room { get; set; } = null!;
    }

    public enum BookingStatus
    {
        Confirmed,
        Cancelled,
        Completed
    }
}
