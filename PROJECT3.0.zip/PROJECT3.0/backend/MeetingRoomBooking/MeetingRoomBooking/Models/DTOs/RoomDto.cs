﻿namespace MeetingRoomBooking.API.Models.DTOs
{
    public class CreateRoomDto
    {
        public string Name { get; set; } = string.Empty;
        public int Capacity { get; set; }
        public string Location { get; set; } = string.Empty;
        public string Amenities { get; set; } = string.Empty;
    }

    public class RoomResponseDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Capacity { get; set; }
        public string Location { get; set; } = string.Empty;
        public string Amenities { get; set; } = string.Empty;
        public bool IsActive { get; set; }
    }

    public class RoomWithAvailabilityDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Capacity { get; set; }
        public string Location { get; set; } = string.Empty;
        public string Amenities { get; set; } = string.Empty;
        public List<TimeSlotDto> BookedSlots { get; set; } = new();
    }

    public class TimeSlotDto
    {
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime { get; set; }
        public string MeetingTitle { get; set; } = string.Empty;
        public string BookedBy { get; set; } = string.Empty;
    }
}
