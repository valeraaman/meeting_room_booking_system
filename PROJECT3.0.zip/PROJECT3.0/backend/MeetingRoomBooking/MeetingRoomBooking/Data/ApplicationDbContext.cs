﻿using MeetingRoomBooking.API.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace MeetingRoomBooking.API.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Room> Rooms { get; set; }
        public DbSet<Booking> Bookings { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Room configuration
            modelBuilder.Entity<Room>(entity =>
            {
                entity.HasKey(r => r.Id);
                entity.Property(r => r.Name).IsRequired().HasMaxLength(100);
                entity.Property(r => r.Location).HasMaxLength(200);
                entity.Property(r => r.Amenities).HasMaxLength(500);
                entity.HasIndex(r => r.Name).IsUnique();
            });

            // Booking configuration
            modelBuilder.Entity<Booking>(entity =>
            {
                entity.HasKey(b => b.Id);
                entity.Property(b => b.EmployeeId).IsRequired().HasMaxLength(50);
                entity.Property(b => b.EmployeeName).IsRequired().HasMaxLength(100);
                entity.Property(b => b.MeetingTitle).IsRequired().HasMaxLength(200);
                entity.Property(b => b.Description).HasMaxLength(1000);

                entity.HasOne(b => b.Room)
                    .WithMany(r => r.Bookings)
                    .HasForeignKey(b => b.RoomId)
                    .OnDelete(DeleteBehavior.Restrict);

                // Index for efficient conflict checking
                entity.HasIndex(b => new { b.RoomId, b.BookingDate, b.StartTime, b.EndTime });
            });

            // Seed data
            modelBuilder.Entity<Room>().HasData(
                new Room { Id = 1, Name = "Conference Room A", Capacity = 10, Location = "Floor 1", Amenities = "Projector, Whiteboard, Video Conferencing" },
                new Room { Id = 2, Name = "Conference Room B", Capacity = 6, Location = "Floor 1", Amenities = "TV Screen, Whiteboard" },
                new Room { Id = 3, Name = "Board Room", Capacity = 20, Location = "Floor 2", Amenities = "Projector, Video Conferencing, Catering" },
                new Room { Id = 4, Name = "Huddle Space 1", Capacity = 4, Location = "Floor 1", Amenities = "TV Screen" },
                new Room { Id = 5, Name = "Training Room", Capacity = 30, Location = "Floor 3", Amenities = "Projector, Computers, Whiteboard" }
            );
        }
    }
}
