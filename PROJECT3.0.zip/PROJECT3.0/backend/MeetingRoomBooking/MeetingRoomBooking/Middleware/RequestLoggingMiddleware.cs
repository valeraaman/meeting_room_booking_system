﻿using System.Diagnostics;

namespace MeetingRoomBooking.API.Middleware
{
    public class RequestLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<RequestLoggingMiddleware> _logger;

        public RequestLoggingMiddleware(RequestDelegate next, ILogger<RequestLoggingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var requestId = Guid.NewGuid().ToString("N")[..8];
            var stopwatch = Stopwatch.StartNew();

            // Log request
            _logger.LogInformation(
                "[{RequestId}] {Method} {Path} - Started at {Time}",
                requestId,
                context.Request.Method,
                context.Request.Path,
                DateTime.UtcNow.ToString("HH:mm:ss.fff"));

            // Add request ID to response headers
            context.Response.Headers.Append("X-Request-Id", requestId);

            try
            {
                await _next(context);

                stopwatch.Stop();

                // Log response
                _logger.LogInformation(
                    "[{RequestId}] {Method} {Path} - Completed with {StatusCode} in {ElapsedMs}ms",
                    requestId,
                    context.Request.Method,
                    context.Request.Path,
                    context.Response.StatusCode,
                    stopwatch.ElapsedMilliseconds);
            }
            catch (Exception ex)
            {
                stopwatch.Stop();

                _logger.LogError(ex,
                    "[{RequestId}] {Method} {Path} - Failed after {ElapsedMs}ms: {Message}",
                    requestId,
                    context.Request.Method,
                    context.Request.Path,
                    stopwatch.ElapsedMilliseconds,
                    ex.Message);

                throw;
            }
        }
    }

    public static class RequestLoggingMiddlewareExtensions
    {
        public static IApplicationBuilder UseRequestLogging(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RequestLoggingMiddleware>();
        }
    }
}
