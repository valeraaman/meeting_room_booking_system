﻿using Microsoft .AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MeetingRoomBooking.API.Data;
using MeetingRoomBooking.API.Models;
using MeetingRoomBooking.API.Models.DTOs;
using MeetingRoomBooking.API.Middleware;

namespace MeetingRoomBooking.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RoomsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<RoomsController> _logger;

        public RoomsController(ApplicationDbContext context, ILogger<RoomsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/rooms
        [HttpGet]
        public async Task<ActionResult<IEnumerable<RoomResponseDto>>> GetRooms()
        {
            _logger.LogInformation("Fetching all rooms");

            var rooms = await _context.Rooms
                .Where(r => r.IsActive)
                .Select(r => new RoomResponseDto
                {
                    Id = r.Id,
                    Name = r.Name,
                    Capacity = r.Capacity,
                    Location = r.Location,
                    Amenities = r.Amenities,
                    IsActive = r.IsActive
                })
                .ToListAsync();

            return Ok(rooms);
        }

        // GET: api/rooms/5
        [HttpGet("{id}")]
        public async Task<ActionResult<RoomResponseDto>> GetRoom(int id)
        {
            _logger.LogInformation("Fetching room with ID: {RoomId}", id);

            var room = await _context.Rooms.FindAsync(id);

            if (room == null)
            {
                throw new NotFoundException($"Room with ID {id} not found");
            }

            return Ok(new RoomResponseDto
            {
                Id = room.Id,
                Name = room.Name,
                Capacity = room.Capacity,
                Location = room.Location,
                Amenities = room.Amenities,
                IsActive = room.IsActive
            });
        }

        // GET: api/rooms/5/availability?date=2024-01-15
        [HttpGet("{id}/availability")]
        public async Task<ActionResult<RoomWithAvailabilityDto>> GetRoomAvailability(int id, [FromQuery] DateTime date)
        {
            _logger.LogInformation("Checking availability for room {RoomId} on {Date}", id, date.Date);

            var room = await _context.Rooms.FindAsync(id);

            if (room == null)
            {
                throw new NotFoundException($"Room with ID {id} not found");
            }

            var bookings = await _context.Bookings
                .Where(b => b.RoomId == id &&
                           b.BookingDate.Date == date.Date &&
                           b.Status == BookingStatus.Confirmed)
                .OrderBy(b => b.StartTime)
                .Select(b => new TimeSlotDto
                {
                    StartTime = b.StartTime,
                    EndTime = b.EndTime,
                    MeetingTitle = b.MeetingTitle,
                    BookedBy = b.EmployeeName
                })
                .ToListAsync();

            return Ok(new RoomWithAvailabilityDto
            {
                Id = room.Id,
                Name = room.Name,
                Capacity = room.Capacity,
                Location = room.Location,
                Amenities = room.Amenities,
                BookedSlots = bookings
            });
        }

        // GET: api/rooms/available?date=2024-01-15&startTime=09:00&endTime=10:00&capacity=5
        [HttpGet("available")]
        public async Task<ActionResult<IEnumerable<RoomResponseDto>>> GetAvailableRooms(
            [FromQuery] DateTime date,
            [FromQuery] TimeSpan startTime,
            [FromQuery] TimeSpan endTime,
            [FromQuery] int? capacity)
        {
            _logger.LogInformation("Finding available rooms for {Date} from {Start} to {End}",
                date.Date, startTime, endTime);

            var query = _context.Rooms.Where(r => r.IsActive);

            if (capacity.HasValue)
            {
                query = query.Where(r => r.Capacity >= capacity.Value);
            }

            var rooms = await query.ToListAsync();

            var availableRooms = new List<RoomResponseDto>();

            foreach (var room in rooms)
            {
                var hasConflict = await _context.Bookings
                    .AnyAsync(b => b.RoomId == room.Id &&
                                  b.BookingDate.Date == date.Date &&
                                  b.Status == BookingStatus.Confirmed &&
                                  b.StartTime < endTime &&
                                  b.EndTime > startTime);

                if (!hasConflict)
                {
                    availableRooms.Add(new RoomResponseDto
                    {
                        Id = room.Id,
                        Name = room.Name,
                        Capacity = room.Capacity,
                        Location = room.Location,
                        Amenities = room.Amenities,
                        IsActive = room.IsActive
                    });
                }
            }

            return Ok(availableRooms);
        }

        // POST: api/rooms
        [HttpPost]
        public async Task<ActionResult<RoomResponseDto>> CreateRoom(CreateRoomDto dto)
        {
            _logger.LogInformation("Creating new room: {RoomName}", dto.Name);

            var existingRoom = await _context.Rooms
                .AnyAsync(r => r.Name.ToLower() == dto.Name.ToLower());

            if (existingRoom)
            {
                throw new ValidationException($"A room with name '{dto.Name}' already exists");
            }

            var room = new Room
            {
                Name = dto.Name,
                Capacity = dto.Capacity,
                Location = dto.Location,
                Amenities = dto.Amenities,
                IsActive = true
            };

            _context.Rooms.Add(room);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Room created with ID: {RoomId}", room.Id);

            return CreatedAtAction(nameof(GetRoom), new { id = room.Id }, new RoomResponseDto
            {
                Id = room.Id,
                Name = room.Name,
                Capacity = room.Capacity,
                Location = room.Location,
                Amenities = room.Amenities,
                IsActive = room.IsActive
            });
        }

        // PUT: api/rooms/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRoom(int id, CreateRoomDto dto)
        {
            _logger.LogInformation("Updating room with ID: {RoomId}", id);

            var room = await _context.Rooms.FindAsync(id);

            if (room == null)
            {
                throw new NotFoundException($"Room with ID {id} not found");
            }

            var duplicateName = await _context.Rooms
                .AnyAsync(r => r.Id != id && r.Name.ToLower() == dto.Name.ToLower());

            if (duplicateName)
            {
                throw new ValidationException($"A room with name '{dto.Name}' already exists");
            }

            room.Name = dto.Name;
            room.Capacity = dto.Capacity;
            room.Location = dto.Location;
            room.Amenities = dto.Amenities;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Room {RoomId} updated successfully", id);

            return NoContent();
        }

        // DELETE: api/rooms/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRoom(int id)
        {
            _logger.LogInformation("Deleting room with ID: {RoomId}", id);

            var room = await _context.Rooms.FindAsync(id);

            if (room == null)
            {
                throw new NotFoundException($"Room with ID {id} not found");
            }

            // Check for future bookings
            var hasFutureBookings = await _context.Bookings
                .AnyAsync(b => b.RoomId == id &&
                              b.BookingDate >= DateTime.Today &&
                              b.Status == BookingStatus.Confirmed);

            if (hasFutureBookings)
            {
                throw new ValidationException("Cannot delete room with future bookings. Cancel bookings first.");
            }

            // Soft delete
            room.IsActive = false;
            await _context.SaveChangesAsync();

            _logger.LogInformation("Room {RoomId} soft deleted", id);

            return NoContent();
        }
    }
}
