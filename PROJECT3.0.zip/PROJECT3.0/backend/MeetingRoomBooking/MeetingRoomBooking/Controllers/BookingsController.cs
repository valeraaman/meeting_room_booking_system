﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MeetingRoomBooking.API.Data;
using MeetingRoomBooking.API.Models;
using MeetingRoomBooking.API.Models.DTOs;
using MeetingRoomBooking.API.Middleware;

namespace MeetingRoomBooking.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookingsController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<BookingsController> _logger;

        public BookingsController(ApplicationDbContext context, ILogger<BookingsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: api/bookings
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BookingResponseDto>>> GetBookings(
            [FromQuery] DateTime? date,
            [FromQuery] int? roomId,
            [FromQuery] string? employeeId)
        {
            _logger.LogInformation("Fetching bookings with filters - Date: {Date}, RoomId: {RoomId}, EmployeeId: {EmployeeId}",
                date, roomId, employeeId);

            var query = _context.Bookings
                .Include(b => b.Room)
                .AsQueryable();

            if (date.HasValue)
            {
                query = query.Where(b => b.BookingDate.Date == date.Value.Date);
            }

            if (roomId.HasValue)
            {
                query = query.Where(b => b.RoomId == roomId.Value);
            }

            if (!string.IsNullOrEmpty(employeeId))
            {
                query = query.Where(b => b.EmployeeId == employeeId);
            }

            var bookings = await query
                .OrderBy(b => b.BookingDate)
                .ThenBy(b => b.StartTime)
                .Select(b => new BookingResponseDto
                {
                    Id = b.Id,
                    RoomId = b.RoomId,
                    RoomName = b.Room.Name,
                    EmployeeId = b.EmployeeId,
                    EmployeeName = b.EmployeeName,
                    MeetingTitle = b.MeetingTitle,
                    Description = b.Description,
                    BookingDate = b.BookingDate,
                    StartTime = b.StartTime,
                    EndTime = b.EndTime,
                    AttendeesCount = b.AttendeesCount,
                    Status = b.Status.ToString(),
                    CreatedAt = b.CreatedAt
                })
                .ToListAsync();

            return Ok(bookings);
        }

        // GET: api/bookings/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BookingResponseDto>> GetBooking(int id)
        {
            _logger.LogInformation("Fetching booking with ID: {BookingId}", id);

            var booking = await _context.Bookings
                .Include(b => b.Room)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (booking == null)
            {
                throw new NotFoundException($"Booking with ID {id} not found");
            }

            return Ok(new BookingResponseDto
            {
                Id = booking.Id,
                RoomId = booking.RoomId,
                RoomName = booking.Room.Name,
                EmployeeId = booking.EmployeeId,
                EmployeeName = booking.EmployeeName,
                MeetingTitle = booking.MeetingTitle,
                Description = booking.Description,
                BookingDate = booking.BookingDate,
                StartTime = booking.StartTime,
                EndTime = booking.EndTime,
                AttendeesCount = booking.AttendeesCount,
                Status = booking.Status.ToString(),
                CreatedAt = booking.CreatedAt
            });
        }

        // GET: api/bookings/my-bookings/{employeeId}
        [HttpGet("my-bookings/{employeeId}")]
        public async Task<ActionResult<IEnumerable<BookingResponseDto>>> GetMyBookings(string employeeId)
        {
            _logger.LogInformation("Fetching bookings for employee: {EmployeeId}", employeeId);

            var bookings = await _context.Bookings
                .Include(b => b.Room)
                .Where(b => b.EmployeeId == employeeId && b.BookingDate >= DateTime.Today)
                .OrderBy(b => b.BookingDate)
                .ThenBy(b => b.StartTime)
                .Select(b => new BookingResponseDto
                {
                    Id = b.Id,
                    RoomId = b.RoomId,
                    RoomName = b.Room.Name,
                    EmployeeId = b.EmployeeId,
                    EmployeeName = b.EmployeeName,
                    MeetingTitle = b.MeetingTitle,
                    Description = b.Description,
                    BookingDate = b.BookingDate,
                    StartTime = b.StartTime,
                    EndTime = b.EndTime,
                    AttendeesCount = b.AttendeesCount,
                    Status = b.Status.ToString(),
                    CreatedAt = b.CreatedAt
                })
                .ToListAsync();

            return Ok(bookings);
        }

        // POST: api/bookings
        [HttpPost]
        public async Task<ActionResult<BookingResponseDto>> CreateBooking(CreateBookingDto dto)
        {
            _logger.LogInformation("Creating booking for room {RoomId} on {Date} from {Start} to {End}",
                dto.RoomId, dto.BookingDate, dto.StartTime, dto.EndTime);

            // Validate room exists
            var room = await _context.Rooms.FindAsync(dto.RoomId);
            if (room == null)
            {
                throw new NotFoundException($"Room with ID {dto.RoomId} not found");
            }

            if (!room.IsActive)
            {
                throw new ValidationException("Cannot book an inactive room");
            }

            // Validate time
            if (dto.StartTime >= dto.EndTime)
            {
                throw new ValidationException("End time must be after start time");
            }

            // Validate booking date is not in the past
            if (dto.BookingDate.Date < DateTime.Today)
            {
                throw new ValidationException("Cannot book a room for a past date");
            }

            // Validate attendees count against room capacity
            if (dto.AttendeesCount > room.Capacity)
            {
                return BadRequest(new
                {
                    message = $"Room '{room.Name}' capacity is only {room.Capacity}. You entered {dto.AttendeesCount} attendees."
                });
            }

            // Check for double booking (core feature)
            var hasConflict = await _context.Bookings
                .AnyAsync(b => b.RoomId == dto.RoomId &&
                              b.BookingDate.Date == dto.BookingDate.Date &&
                              b.Status == BookingStatus.Confirmed &&
                              b.StartTime < dto.EndTime &&
                              b.EndTime > dto.StartTime);

            if (hasConflict)
            {
                _logger.LogWarning("Booking conflict detected for room {RoomId} on {Date} from {Start} to {End}",
                    dto.RoomId, dto.BookingDate, dto.StartTime, dto.EndTime);

                throw new BookingConflictException(
                    $"Room '{room.Name}' is already booked during the requested time slot on {dto.BookingDate:yyyy-MM-dd}");
            }

            var booking = new Booking
            {
                RoomId = dto.RoomId,
                EmployeeId = dto.EmployeeId,
                EmployeeName = dto.EmployeeName,
                MeetingTitle = dto.MeetingTitle,
                Description = dto.Description,
                BookingDate = dto.BookingDate.Date,
                StartTime = dto.StartTime,
                EndTime = dto.EndTime,
                AttendeesCount = dto.AttendeesCount,
                Status = BookingStatus.Confirmed,
                CreatedAt = DateTime.UtcNow
            };

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Booking created with ID: {BookingId}", booking.Id);

            return CreatedAtAction(nameof(GetBooking), new { id = booking.Id }, new BookingResponseDto
            {
                Id = booking.Id,
                RoomId = booking.RoomId,
                RoomName = room.Name,
                EmployeeId = booking.EmployeeId,
                EmployeeName = booking.EmployeeName,
                MeetingTitle = booking.MeetingTitle,
                Description = booking.Description,
                BookingDate = booking.BookingDate,
                StartTime = booking.StartTime,
                EndTime = booking.EndTime,
                AttendeesCount = booking.AttendeesCount,
                Status = booking.Status.ToString(),
                CreatedAt = booking.CreatedAt
            });
        }

        // PUT: api/bookings/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBooking(int id, CreateBookingDto dto)
        {
            _logger.LogInformation("Updating booking with ID: {BookingId}", id);

            var booking = await _context.Bookings.FindAsync(id);

            if (booking == null)
            {
                throw new NotFoundException($"Booking with ID {id} not found");
            }

            if (booking.Status == BookingStatus.Cancelled)
            {
                throw new ValidationException("Cannot update a cancelled booking");
            }

            // Validate room exists
            var room = await _context.Rooms.FindAsync(dto.RoomId);
            if (room == null)
            {
                throw new NotFoundException($"Room with ID {dto.RoomId} not found");
            }

            // Validate time
            if (dto.StartTime >= dto.EndTime)
            {
                throw new ValidationException("End time must be after start time");
            }

            // Check for conflicts (excluding current booking)
            var hasConflict = await _context.Bookings
                .AnyAsync(b => b.Id != id &&
                              b.RoomId == dto.RoomId &&
                              b.BookingDate.Date == dto.BookingDate.Date &&
                              b.Status == BookingStatus.Confirmed &&
                              b.StartTime < dto.EndTime &&
                              b.EndTime > dto.StartTime);

            if (hasConflict)
            {
                throw new BookingConflictException(
                    $"Room '{room.Name}' is already booked during the requested time slot");
            }

            booking.RoomId = dto.RoomId;
            booking.MeetingTitle = dto.MeetingTitle;
            booking.Description = dto.Description;
            booking.BookingDate = dto.BookingDate.Date;
            booking.StartTime = dto.StartTime;
            booking.EndTime = dto.EndTime;
            booking.AttendeesCount = dto.AttendeesCount;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Booking {BookingId} updated successfully", id);

            return NoContent();
        }

        // DELETE: api/bookings/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> CancelBooking(int id)
        {
            _logger.LogInformation("Cancelling booking with ID: {BookingId}", id);

            var booking = await _context.Bookings.FindAsync(id);

            if (booking == null)
            {
                throw new NotFoundException($"Booking with ID {id} not found");
            }

            if (booking.Status == BookingStatus.Cancelled)
            {
                throw new ValidationException("Booking is already cancelled");
            }

            booking.Status = BookingStatus.Cancelled;
            await _context.SaveChangesAsync();

            _logger.LogInformation("Booking {BookingId} cancelled successfully", id);

            return NoContent();
        }

        // POST: api/bookings/check-availability
        [HttpPost("check-availability")]
        public async Task<ActionResult<bool>> CheckAvailability(RoomAvailabilityDto dto)
        {
            _logger.LogInformation("Checking availability for room {RoomId} on {Date} from {Start} to {End}",
                dto.RoomId, dto.Date, dto.StartTime, dto.EndTime);

            var hasConflict = await _context.Bookings
                .AnyAsync(b => b.RoomId == dto.RoomId &&
                              b.BookingDate.Date == dto.Date.Date &&
                              b.Status == BookingStatus.Confirmed &&
                              b.StartTime < dto.EndTime &&
                              b.EndTime > dto.StartTime);

            return Ok(!hasConflict);
        }
    }
}
